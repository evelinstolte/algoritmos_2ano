<html>
<head>
<meta charset="UTF-8">
<title>Resultados do formulário</title>
</head>

<body>
<h1>Resultados:</h1>
<p>As suas características fisicas são:</p>
<?php
	if(isset($_POST["nome"]) == true){
	$nome = $_POST["nome"];
	echo "o nome da pessoa é: " . $nome . "<br>";
	}
	
	if(isset($_POST["opção"]) == true){
	$opção = $_POST["opção"];
	echo "O seu gênero é: " . $opção . "<br>";
	}
	
	if(isset($_POST["CorOlhos"]) == true){
	$corOlhos = $_POST["CorOlhos"];
	echo "A cor de seus olhos é: " . $corOlhos . "<br>";
	}
	
	if(isset($_POST["altura"]) == true){
	echo "A sua altura é maior que 1,50cm <br>";
	}else{echo "A sua altura é menor que 1,50cm <br>";}
	
	if(isset($_POST["peso"]) == true){
	echo "O seu peso é maior que 60kg <br>";
	}else{echo "O seu peso é menor que 60kg <br>";}
	
	if(isset($_POST["habilidade"]) == true){
	$habilidade = $_POST["habilidade"];
	echo $nome . "As habilidades físicas decritas foram: " . $habilidade . "<br>";
	}
?>
</body>
</html>