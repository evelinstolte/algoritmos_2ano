<?php
/* 2. Crie um script em PHP que crie um vetor com 20 valores aleatórios, entre 0-5, e
imprima-os ao usuário juntamente com o número de vezes em que o valor 3
aparece. Obs: Utilize um while. */
$i = 1;
$t = 0;
$vetor = array();

while($i <= 20){
    $random = rand(0, 5);
    if ($random == 3){
        $t++;
    }
    array_push($vetor, $random);
    $i++;
}
var_dump($vetor);
echo("O 3 apareceu ". $t . " vezes na lista.");