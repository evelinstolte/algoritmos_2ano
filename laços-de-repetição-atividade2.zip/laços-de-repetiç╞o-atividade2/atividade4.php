<?php
/* 4. Escreva um comando que, em uma única linha, transforme o array abaixo em
uma string delimitada por espaços:
$a = array("Maria", "Paula", "Fernanda"); */

$a = array("Maria", "Paula", "Fernanda");
$string = implode(" ", $a);
echo $string;