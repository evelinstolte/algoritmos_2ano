<?php
/* 1. Crie um script em PHP que gere 20 valores aleatórios, entre 100 - 200, e
imprima-os ao usuário. Obs: Utilize um do while. */

$i = 1;
do {
    $random = rand(100, 200);
    echo $random;
    echo "<br>";
    $i++;
} while ($i <= 20);

